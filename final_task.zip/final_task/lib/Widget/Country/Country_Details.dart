
import 'package:flutter/material.dart';

class Country_Details extends StatelessWidget {
  Country_Details({Key key, this.data}) : super(key: key);
  Map data;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.indigo,
        title: Center(child:Text('Details of ${data['name']} ${data['emoji']}',style: TextStyle(color:Colors.yellow,fontSize: 25),),)
      ),
      body: SafeArea(
        child: Container(
          width: MediaQuery
              .of(context)
              .size
              .width,
          height: MediaQuery
              .of(context)
              .size
              .height,
color: Colors.black,
          child: ListView(
            children: [
              //*********************************** 1
              _getData('name'),

              _getData('native'),
              _getData('phone'),

              _getData('continent'),

              _getData('capital'),

              _getData('currency'),

              _getData('Languages'),

              _getData('emoji'),

              _getData('emojiU'),

            ],

          ),
        ),
      ),
    );
  }

  Widget _getData(String name) {
    return Container(
      child: Center(
        child: Text('The $name : ${data['$name']}', style: TextStyle(
            color: Colors.indigo,
            fontSize: 20,
            fontWeight: FontWeight.bold),),
      ),
      padding: EdgeInsets.all(30),
      margin: EdgeInsets.symmetric(
          vertical: 10, horizontal: 20),
      decoration: BoxDecoration( border:Border.all(color: Colors.black),
          color: Colors.white,
          borderRadius: BorderRadius.circular(15)),


    );
  }
}


