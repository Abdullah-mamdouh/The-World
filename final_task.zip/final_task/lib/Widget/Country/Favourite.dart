
import 'package:flutter/material.dart';
class Favourite extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
