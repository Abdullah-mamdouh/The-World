
import 'package:flutter/material.dart';

import '../Mehtods.dart';
import 'Country_Details.dart';

class Countries extends StatelessWidget {
  String con_key;

  Countries({Key key, this.con_key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.indigo,
        title: Padding(padding: EdgeInsets.only(left: 60),
          child:Text("Countries",style: TextStyle(color:Colors.yellow,fontSize: 25),),)
      ),
      body:Container(
        child: FutureBuilder<Map>(
        future: Data().loadAllData_Countries(),
    builder: (context, snapshot) {
    if (snapshot.data != null) {
    List<MapEntry> countries = snapshot.data.entries
        .where((element) =>
    element.value['continent'] == con_key)
        .toList();
    print(countries[0].value['name'].toString());
    return Container( color: Colors.black,
    child: ListView(
        children: List.generate(countries.length, (index) {

          return GestureDetector(
            onTap: () {
              Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => Country_Details(
                        data: countries[index].value,
                      )));
            },
            child:Container(
              child: Center(
                child: Text('${countries[index].value['name'].toString()}', style: TextStyle(
                    color: Colors.indigo,
                    fontSize: 20,
                    fontWeight: FontWeight.bold),),
              ),
              padding: EdgeInsets.all(20),
              margin: EdgeInsets.symmetric(
                  vertical: 10, horizontal: 20),
              decoration: BoxDecoration( border:Border.all(color: Colors.black),
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(15)),


            ),
//          child:Center(
//            child:Container(
//
//              alignment: Alignment.center,
//              margin: EdgeInsets.only(top: 20,right: 25,left: 25,bottom: 5),
//              width: double.infinity, height: 30,
//              decoration: BoxDecoration(borderRadius: BorderRadius.circular(20),color: Colors.white),
//              child: Expanded(
//                child: Text('${countries[index].value['name'].toString()}',
//                  style: TextStyle(color: Colors.black,fontSize: 20),),
//              ),
//
////        Text('${countries[index].value['name'].toString()}',
////          style: TextStyle(color: Colors.white,fontSize: 20),),
//            ),
//          ),
          );

          //Text('${countries[index].value['name'].toString()}');
//    return Center(
//      child:Container(
//        alignment: Alignment.center,
//        margin: EdgeInsets.all(10),
//        width: 200, height: 30,
//        decoration: BoxDecoration(borderRadius: BorderRadius.circular(20),color: Colors.black),
//        child:InkWell(
//          splashColor: Colors.black,
//          //highlightColor: Colors.blue,
//          child: Text('${countries[index].value['name'].toString()}',
//              style: TextStyle(color:Colors.white,fontSize: 20,fontWeight: FontWeight.bold)),
//          onTap: () {
//            Navigator.push(
//                context,
//                MaterialPageRoute(
//                    builder: (context) => Country_Details(
//                      data: countries[index].value,
//                    )));
//          },
//        ),
//      ),
//    );
//      Stack(
//    alignment: Alignment.topRight,
//    children: [
//    InkWell(
//      child: Text('${countries[index].value.toString()}'),
//    onTap: () {
//    Navigator.push(
//    context,
//    MaterialPageRoute(
//    builder: (context) => Country_Details(
//    data: countries[index].value,
//    )));
//    },
//    ),
//    ],
//    );
        })
    ),);//Text('fghjkl;');

    }
    }
        ),
      ),
    );
  }
}

