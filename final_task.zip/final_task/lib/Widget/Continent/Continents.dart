
import 'package:final_task/Widget/Country/Countries.dart';
import 'package:flutter/material.dart';

import '../Mehtods.dart';

class Continent extends StatefulWidget {
  @override
  _State createState() => _State();
}

class _State extends State<Continent> {
  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.black,
        height: double.infinity,
        width: double.infinity,
        child:FutureBuilder<Map<dynamic,dynamic>>(
        future: Data().loadAllData_Continents(),
    //***************************************************
    // Favourite screen
    builder: (context, snapshot) {
      //  print(list);
      if (snapshot.data != null) {

        //return Text('${snapshot.data["AD"]["name"].toString()}');
        Iterable<String> list = snapshot.data.keys;
        print(list.toString());
//
        return Container(
          color: Colors.black,
          padding: EdgeInsets.only(top: 40),
          child:ListView(
            children: List.generate(snapshot.data.length, (index) {
              return Center(
                child:Container(
                  alignment: Alignment.center,
                  margin: EdgeInsets.all(10),
                  width: 230, height: 50,
                  decoration: BoxDecoration(borderRadius: BorderRadius.circular(20),color: Colors.white),
                  child:InkWell(
                    splashColor: Colors.white,
                    //highlightColor: Colors.blue,
                    child: Text('${snapshot.data.values.elementAt(index).toString()}'
                        , style: TextStyle(
                        color: Colors.indigo,
                        fontSize: 20,
                        fontWeight: FontWeight.bold),),
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => Countries(
                            con_key: list.elementAt(index),
                          ),
                        ),
                      );
                    },
                  ),
                ),
              );

              //Text('${snapshot.data[list.elementAt(index)]["name"].toString()}');
            }
            ),
          ) ,
        );
      }
    }
    ),

    );
  }
}
