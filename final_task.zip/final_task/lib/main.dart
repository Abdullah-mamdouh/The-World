


import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'Model/Country.dart';
import 'Model/Language.dart';
import 'Widget/Continent/Continents.dart';
import 'Widget/Country/Favourite.dart';
import 'Widget/Mehtods.dart';

void main() {
  runApp(MyHomePage());
}


class MyHomePage extends StatefulWidget {
  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {

  int _selectedIndex = 0;
  static const TextStyle optionStyle =
  TextStyle(fontSize: 30, fontWeight: FontWeight.bold);
  final List<Widget> _widgetOptions = [
    Continent(),
    Favourite(),
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }
bool _isDark= false;
  ThemeData _light = ThemeData.light().copyWith(
    primaryColor: Colors.indigo,
  );
  ThemeData _dark = ThemeData.dark().copyWith(
    primaryColor: Colors.blueGrey,
  );

  void toggleSwitch(bool value) {

    if(_isDark == false)
    {
      setState(() {
        _isDark = true;
      });
      print('Switch Button is ON');
    }
    else
    {
      setState(() {
        _isDark = false;
      });
      print('Switch Button is OFF');
    }
  }
  Future<Map> dataCountry ;
  var db = Data();


  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    dataCountry = db.loadAllData_Countries() ;
  }
  int _counter = 0;

List<String>list;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      darkTheme: _dark,
      theme: _light,
      themeMode: _isDark ? ThemeMode.dark : ThemeMode.light,
      debugShowCheckedModeBanner: false,
      home:
     Scaffold(
      appBar: AppBar(

        title: Text("The World"),
        backgroundColor: Colors.indigo,
      ),
      body:_widgetOptions[_selectedIndex],

      bottomNavigationBar: BottomNavigationBar(
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',

          ),

          BottomNavigationBarItem(
            icon: Icon(Icons.favorite),
            label: 'Favourite',
          ),
        ],
        currentIndex: _selectedIndex,
        selectedItemColor: Colors.amber[800],
        onTap: _onItemTapped,
      ),
    drawer:Drawer(
      child: ListView(
        // Important: Remove any padding from the ListView.
        padding: EdgeInsets.zero,
        children: <Widget>[
          UserAccountsDrawerHeader(
            accountName: Text("Abhishek Mishra"),
            accountEmail: Text("abhishekm977@gmail.com"),
            currentAccountPicture: CircleAvatar(
              backgroundColor: Colors.orange,
              child: Text(
                "A",
                style: TextStyle(fontSize: 40.0),
              ),
            ),
          ),
        Container(
          width: 15,
          height: 20,
          child:Switch(

            onChanged: toggleSwitch,
            value: _isDark,
            activeColor: Colors.blue,
            activeTrackColor: Colors.white,
            inactiveThumbColor: Colors.redAccent,
            inactiveTrackColor: Colors.black,
          ),
        ),


    ListTile(
            leading: Icon(Icons.home), title: Text("Home"),
            onTap: () {
              Navigator.pop(context);
            },
          ),
          ListTile(
            leading: Icon(Icons.settings), title: Text("Settings"),
            onTap: () {
              Navigator.pop(context);
            },
          ),
          ListTile(
            leading: Icon(Icons.contacts), title: Text("Contact Us"),
            onTap: () {
              Navigator.pop(context);
            },
          ),
        ],
      ),
    ),
    //MyHome(),
//
//      Container(
//        height: double.infinity,
//        width: double.infinity,
//        child:FutureBuilder<Map<dynamic,dynamic>>(
//          future: Data().loadAllData_Continents(),
//          //***************************************************
//          // Favourite screen
//          builder: (context, snapshot) {
//            //  print(list);
//            if (snapshot.data != null) {
//                     // List<String> list = [];
////                      List<MapEntry> countries = snapshot.data
////                          .cast<String, Map>()
////                          .entries
////                          .where((element) {
////                        print(element.value['name']);
////                        return list.contains(element.value['name']);
////                      }).toList();
//
//                      print('sjk');
//              //return Text('${snapshot.data["AD"]["name"].toString()}');
//              Iterable<String> list = snapshot.data.keys ;
//              print(list.toString());
////                       for(int i =0;i<snapshot.data.length;i++){
////                         Text('${snapshot.data[list.elementAt(i)]["name"].toString()}');
////                      }
////                      print(snapshot.data.length.toString());
//    return ListView(
//    children: List.generate(snapshot.data.length, (index) {
//      return Text('${snapshot.data.values.elementAt(index).toString()}');
//        //Text('${snapshot.data[list.elementAt(index)]["name"].toString()}');
//              }
//            ),
//    );
////      return Container(
////        padding: EdgeInsets.all(30),
////        margin: EdgeInsets.symmetric(
////            vertical: 10, horizontal: 20),
////        decoration: BoxDecoration(
////            color: Colors.white,
////            borderRadius: BorderRadius.circular(15)),
////        child: Center(
////          child: Text(countries[index].value['name'],
////              style: TextStyle(
////                  color: Colors.indigo,
////                  fontSize: 20,
////                  fontWeight: FontWeight.bold)),
////        ),
////      );
////
////                      })
////                  );
//
//
//                    // return Text('${snapshot.data["AD"]["name"].toString()}');
//                      //Iterable<String> list = snapshot.data.keys ;
//                      //print(list.toString());
////                       for(int i =0;i<snapshot.data.length;i++){
////                         Text('${snapshot.data[list.elementAt(i)]["name"].toString()}');
////                      }
//                      //return Text('${snapshot.data[list.elementAt(249)]["name"].toString()}');
//
////                     return Container(
////                       child: ListView.builder( Text('${snapshot.data[list.elementAt(249)]["name"].toString()}');
//
//
////
////                           itemCount: snapshot.data.length,
////
////                           itemBuilder: (BuildContext context, index) {
////
////return GridView.builder(
////                        itemCount: snapshot.data.length,
////                          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
////                              crossAxisCount: 1,childAspectRatio: 8,
////                              crossAxisSpacing: 8.0,
////                              mainAxisSpacing: 4.0
////                          ),
////                          itemBuilder: (context, index) {
////                        return Text('${countries[index].value["name"].toString()}');
////
////                          Text('${snapshot.data[list.elementAt(index)]["name"].toString()}');
////                      }
////                  );
////                             return Text('${snapshot.data[list.elementAt(index)]['name'].toString()}');
////
//////
////                           }),
////                     );
//                    }
//                  }
//
//            ),
//
//
//
//
//      ),

       // This trailing comma makes auto-formatting nicer for build methods.
    ),
    );
  }
}
