import 'dart:convert';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'package:flutter/services.dart' as rootBundle;

import 'Country.dart';


class MyHome extends StatefulWidget {
  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHome> {


  List _items = [] ;

  // Fetch content from the json file
  Future<Map<String,dynamic>> readJson() async {
    final String response = await rootBundle.rootBundle.loadString('json/data.json');
    Map<String, dynamic> user = json.decode(response);
    Map<String, dynamic> name = user["countries"];
    return name;
    //List<Map<Country, dynamic>>.from(json.decode(response)['countries']);
    //List<Map<Country, dynamic>>.from(name);
   // print (user.toString());
   //return user.map<Country>((e) => Country.fromJson(e)).toList();
//
//    print (name.length.toString());
//    List<Country> list=[];

//    for (int i = 0; i < name.length; i++) {
//      list.add(Country.fromJson(name[i]));
//      Country customObject= Country(
//         name:name[i]["name"],
//          native:name[i]['native'],
//          emojeiU: name[i]['emojeiU'],
//        emoji: name[i]['emoji'],
//        languages: name[i]['countries'],
//        currency: name[i]['countries'],
//        capital: name[i]['countries'],
//        continent: name[i]['countries'],
//        phone: name[i]['countries']
    // );
     // list.add(customObject);
   // }



    //print(list.toString());
    //List<Map<Country, dynamic>>.from(name);
//    print (_items.toString());
//    return _items;
//    final data = await json.decode(response);
//    setState(() {
//      _items = data["countries"];
//    });

  }



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Text(
          'Kindacode.com',
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(25),
        child: Column(
          children: [
//            ElevatedButton(
//              child: Text('Load Data'),
//              onPressed: readJson,
//            ),


            FutureBuilder<Map<String,dynamic>>(
                future: readJson(),
                builder: (context, snapshot) {
                  if(snapshot.data ==null){
                    return Text("error");
                  }
                  if (snapshot.data != null) {
                    if (snapshot.hasData) {
                      return GridView.builder(

                          itemCount: snapshot.data.length,
                          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                            crossAxisCount: 1, childAspectRatio: 8,
//                            crossAxisSpacing: 8.0,
//                            mainAxisSpacing: 8.0
                          ),
                          itemBuilder: (context, index) {
                            print(index);
                            return new Column(
                              children: <Widget>[
                                new ListTile(
                                  leading: CircleAvatar(
                                    child: Text(snapshot.data[index].phone),
                                  ),

                                ),

                                new Divider(),
                              ],
                            );
                          });
                    }
                  }
                }
            ),

            // Display the data loaded from sample.json

          ],
        ),
      ),
    );
  }

  /*Future<List<Map<Country, dynamic>>> ReadJsonData() async {
    final jsondata = await rootBundle.rootBundle.loadString('json/data.json');
//    final list = json.decode(jsondata) as List<dynamic>;
//    return list.toList();
      //list.map((e) => Country.fromJson(e)).toList();
    return List<Map<Country, dynamic>>.from(json.decode(jsondata)['countries']);
   /* Map<String, dynamic> map = json.decode(jsondata);
    List<dynamic> data = map["countries"];
    return data = List<dynamic>.from(
    data.map<dynamic>(
    (dynamic item) => item,
    ),
    );
    //return _data;*/

  }*/
}